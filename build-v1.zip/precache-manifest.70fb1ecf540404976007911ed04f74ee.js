self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "9ddd8c469312cba24b04",
    "url": "/static/js/main.9ddd8c46.chunk.js"
  },
  {
    "revision": "4520dc01270d1cb4fc30",
    "url": "/static/js/1.4520dc01.chunk.js"
  },
  {
    "revision": "f379e7ce5a7bd53793a3672dd24425ee",
    "url": "/index.html"
  }
];